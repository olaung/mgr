﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;

namespace WebApplication6.Pages
{
    public class LibrariesModel : PageModel
    {
        private readonly ILogger<LibrariesModel> _logger;

        public LibrariesModel(ILogger<LibrariesModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            string dateTime = DateTime.Now.ToShortDateString();
            ViewData["TimeStamp"] = dateTime;
        }
    }
}
