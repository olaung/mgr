﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;

namespace WebApplication6.Pages
{
    public class InformationsModel : PageModel
    {
        private readonly ILogger<InformationsModel> _logger;

        public InformationsModel(ILogger<InformationsModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            string dateTime = DateTime.Now.ToShortDateString();
            ViewData["TimeStamp"] = dateTime;
            
            //float mov =  ;
            //ViewData["Mova"] = mov;
        }
    }
}
