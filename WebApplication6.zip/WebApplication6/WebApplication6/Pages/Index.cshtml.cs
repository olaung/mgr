﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace WebApplication6.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        /*
        
        public check(string button)
        {
            if (button=="first")
            {
                TempData["buttonval"] = "First button clicked";
            }
            else
            {
                TempData["buttonval"] = "Secondon clicked";
            }

           return (RedirectToAction("Index")).ToString;
        }
        


        public void Button1_clicked()
        {

        }

        */
        public void OnGet()
        {

        }
    }
}
