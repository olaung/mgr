using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace WebApplication6.Pages
{
    public class Index1Model : PageModel
    {

        private readonly ILogger<IndexModel> _logger;

        public Index1Model(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }
        public void OnGet()
        {
        }
    }
}
