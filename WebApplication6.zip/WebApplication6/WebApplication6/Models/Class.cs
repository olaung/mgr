﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Signal_Filtering_Web_App.Models
{
    public class Class
    {
    }
}
